function submitConnection(address) {
    localStorage.setItem("address", address)
    location.href = "dev.html"
}